This folder contains two base templates for PHPDocX.

If you wish to create your own you may do so starting from scratch or modifying an existing one

We do not recommend to modify an existing default template:

	- phpdocxBaseTemplate.docx
	- phpdocxBaseTemplateNumberedHeadings.docx

Because the standard microsoft Word interface may change its structure behind the curtains and break a property taht may be used by PHPDocX.

Nevertheless if you still choose to do so, please, first of all do a backup of the file to make sure you may return to the original version.